/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package EmployeeApp;
import EmployeeStructure.SingleNode;
import javax.swing.JOptionPane;

/**
 *
 * @author Sameed
 */
    class Employee{
     SingleNode head;
     SingleNode tail;
     SingleNode sorted;
     int size;

    public void createSingleLinkedList(int ID,String name,String email,String contactno,String designation,double salary) {
        head = new SingleNode();
        SingleNode node = new SingleNode();
        node.setID(ID);
        node.setName(name);
        node.setEmail(email);
        node.setContactNo(contactno);
        node.setDesignation(designation);
        node.setSalary(salary);
        node.setNext(null);
        head = node;
        tail = node;
        size = 1;
    }
    void insertionSort(SingleNode headOfNode) {
        sorted = null;
        SingleNode current = headOfNode;
        while (current != null) {
            SingleNode next = current.getNext();
            sortedInsert(current);
            current = next;
        }
        head = sorted;
    }
    void sortedInsert(SingleNode node) {
        if (sorted == null || sorted.getID() <= node.getID()) {
            node.setNext(sorted);
            sorted = node;
        }
        else {
            SingleNode current = sorted;
            while (current.getNext() != null && current.getNext().getID() > node.getID()) {
                current = current.getNext();
            }
            node.setNext(current.getNext());
            current.setNext(node);
        }
    }
    public boolean insertInLinkedList(int ID,String name,String email,String contactno,String designation,double salary, int location) {
        if (head == null){
            createSingleLinkedList(ID,name,email,contactno,designation,salary);
        }else {
            SingleNode node = new SingleNode();
            node.setID(ID);
            node.setName(name);
            node.setEmail(email);
            node.setContactNo(contactno);
            node.setDesignation(designation);
            node.setSalary(salary);
            if (existsLinkedList()) {
                return false;
            } else if (location == 0) {// insert at first position
                node.setNext(head);
                head = node;
            } else if (location >= size) {// insert at last position
                node.setNext(null);
                tail.setNext(node);
                tail = node;
            } else {// insert at specified location
                SingleNode tempNode = head;
                int index = 0;
                while (index < location - 1) {// loop till we reach specified node
                    tempNode = tempNode.getNext();
                    index++;
                }//tempNode currently references to node after which we should insert new node
                SingleNode nextNode = tempNode.getNext(); //this is the immediate next node after new node
                tempNode.setNext(node);//update reference of tempNode to reference to new node
                node.setNext(nextNode);//update newly added nodes' next.
            }
            setSize(getSize()+1);
            return true;
        }
         return true;
    }
    public SingleNode getHead() {
        return head;
    }

    public void setHead(SingleNode head) {
        this.head = head;
    }

    public SingleNode getTail() {
        return tail;
    }

    public void setTail(SingleNode tail) {
        this.tail = tail;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
    public boolean existsLinkedList() {
        return head == null;
    }
    
    //Deletes entire Linked List
    void deleteLinkedList() {
        System.out.println("\n\nDeleting Linked List...");
        if (head != null && tail != null) {
        head = null;
        tail = null;
        JOptionPane.showMessageDialog(null, "All employees data deleted successfully !");}
        else JOptionPane.showMessageDialog(null, "Linked does not exist.");
    }
    //Searches a node with given value
    int searchForNode(int id) {
        SingleNode tempNode = head;
        for (int i = 0; i < getSize(); i++) {
            if (tempNode.getID() == id) {
                return i;
            }
            tempNode = tempNode.getNext();
        }
        return id;
    }
    
//    boolean searchNo
            
    void searchForNodeANdTraverse(int id) {
        SingleNode tempNode = head;
        String str = "";
        for (int i = 0; i < getSize(); i++) {
            if (tempNode.getID() == id) {
            str += tempNode.getID() + "  " + tempNode.getName()+ "  " + tempNode.getEmail()+ "  " + tempNode.getDesignation()+ "  " + tempNode.getContactNo()+ "  " + tempNode.getSalary() + "\n";
            }
            tempNode = tempNode.getNext();
        } if (str.equals(""))
            str = "Data not found.";
        JOptionPane.showMessageDialog(null, str);
    }
    //Deletes a node having a given value
    public boolean deletionOfNode(int location) {
        if (existsLinkedList()) {
            System.out.println("The linked list does not exist!!");
            return false;
        
        } else if (location == 0) { // we want to delete first element
            head = head.getNext();
            setSize(getSize()-1);
            if(getSize() == 0) { 
                tail = null;
                return true;
            }
        }else if (location >= getSize()){ //If location is not in range or equal, then delete last node
            SingleNode tempNode = head;
            for (int i = 0; i < size - 1; i++) {
                tempNode = tempNode.getNext(); 
            }
            if (tempNode == head) { 
                tail = head = null;
                setSize(getSize()-1);
                return true;
            }
            tempNode.setNext(null);
            tail= tempNode;
            setSize(getSize()-1);
        }else { //if any inside node is to be deleted
            SingleNode tempNode = head;
            for (int i = 0; i < location - 1; i++) {
                tempNode = tempNode.getNext(); 
            }
            tempNode.setNext(tempNode.getNext().getNext()); 
            setSize(getSize()-1);
            return true;
        }
        return false;
    }

    public void editdata(int idd, String option)
    {
        SingleNode tempx=head;
        if (tempx == null)
        {
            JOptionPane.showMessageDialog(null, "Data does not exists.");
            return;
        }
            while(tempx.getID()!=idd) {
                tempx=tempx.getNext();
                if (tempx == null)
                {
                    JOptionPane.showMessageDialog(null, "Employee not found with the id " + idd);
                    return;}
            }
        
        String input = JOptionPane.showInputDialog(null, "Enter the new " + option + " below: ", option, 1);
        switch (option) {
            case "ID":
                int newID;
                try {
                    newID = Integer.parseInt(input);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Value could not be converted.");
                    return;
                }
                if (searchForNode(newID) != newID)
            {
                JOptionPane.showMessageDialog(null, "ID duplicated found. Kindly enter another id>>>");
                return;
            }
                tempx.setID(newID);
                JOptionPane.showMessageDialog(null, "Edited successfully.");
                break;
            case "Name":
                String newname = input;
                tempx.setName(newname);
                JOptionPane.showMessageDialog(null, "Edited successfully.");
                break;
            case "Salary":
                double newsalary;
                try {
                    newsalary = Double.parseDouble(input);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Value could not be converted.");
                    return;
                }
                tempx.setSalary(newsalary);
                JOptionPane.showMessageDialog(null, "Edited successfully.");
                break;

            case "Contact No.":
                String newcontact_no = input;
                tempx.setContactNo(newcontact_no);
                JOptionPane.showMessageDialog(null, "Edited successfully.");
                break;
            case "Email":
                String newemail = input;
                tempx.setEmail(newemail);
                JOptionPane.showMessageDialog(null, "Edited successfully.");
                break;
            case "Designation":
                String newdes = input;
                tempx.setDesignation(newdes);
                JOptionPane.showMessageDialog(null, "Edited successfully.");
                break;
            default:
                System.out.println("Enter between 1-7");
                break;
        }
    }
}

